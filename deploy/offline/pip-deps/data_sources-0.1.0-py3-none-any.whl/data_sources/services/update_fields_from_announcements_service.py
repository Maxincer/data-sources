#!/usr/bin/env python3
"""
从 announcements_metadata.json 中读取公告，逐个解析 minoq/maxoq，
结果写入 data/fields_from_announcements.csv。

用法:
  python scripts/update_fields_from_announcements.py
  python scripts/update_fields_from_announcements.py --dry-run
"""

import csv
import json
import os
import sys
import asyncio
from asyncio import Semaphore
from pathlib import Path

from mxz_utils.logging_config import get_logger

DATA_DIR = Path(os.environ["DATA_DIR"])
META_FILE = DATA_DIR / "raw" / "announcements" / "announcements_metadata.json"
OUTPUT_FILE = DATA_DIR / "fields_from_announcements.csv"
DAILY_START = os.environ["DAILY_START_DATE"]
LOG_DIR = Path(os.environ["LOG_DIR"])
LOG_DIR.mkdir(parents=True, exist_ok=True)
logger = get_logger(
    name="FieldsFromAnnouncements",
    level="DEBUG",
    dirpath_logs=str(LOG_DIR),
    logfile_basename="FieldsFromAnnouncements",
)

HEADER = [
    "announcement_id", "publish_date", "exchange",
    "product_code", "security_id", "field", "value",
    "effective_date", "announcement_title", "evidence", "page_url",
]


def load_existing() -> set[str]:
    """加载已有 CSV，返回已解析的 announcement_id 集合。"""
    if not OUTPUT_FILE.exists():
        logger.info("CSV 不存在，从头开始")
        return set()

    seen = set()
    with open(OUTPUT_FILE, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames != HEADER:
            logger.warning("CSV 表头不匹配，重建文件")
            OUTPUT_FILE.unlink()
            return set()
        for row in reader:
            aid = row.get("announcement_id", "").strip()
            if aid:
                seen.add(aid)
    row_count = sum(1 for _ in open(OUTPUT_FILE)) - 1
    logger.info("已有 CSV: %s 条", row_count)
    return seen


def should_parse(entry: dict) -> bool:
    cat = entry.get("category", "")
    pub_date = entry.get("pub_date", "")
    if cat in ("general", "product"):
        return True
    if cat == "daily" and pub_date >= DAILY_START:
        return True
    return False


def main():
    import aiohttp
    from data_sources.parser import (
        _process_html,
        parse_announcement_fields,
        clear_attachment_failures,
        get_attachment_failures,
    )
    clear_attachment_failures()

    seen_ids = load_existing()

    if not META_FILE.exists():
        logger.error("metadata 不存在: %s", META_FILE)
        sys.exit(1)

    with open(META_FILE, "r", encoding="utf-8") as f:
        meta = json.load(f)

    logger.info("metadata 总数: %s 条", len(meta))

    candidates = []
    for aid, entry in meta.items():
        if aid in seen_ids:
            continue
        if not should_parse(entry):
            continue
        sf = entry.get("source_file", "")
        if not sf or not Path(sf).exists():
            logger.debug("跳过 %s: 源文件不存在 %s", aid, sf)
            continue
        candidates.append((aid, entry))

    candidates.sort(key=lambda x: (x[1].get("pub_date", ""), x[0]))
    logger.info("待解析: %s 条", len(candidates))

    if not candidates:
        logger.info("无新公告，退出")
        return

    dry_run = "--dry-run" in sys.argv
    semaphore = int(os.environ["LLM_CONCURRENCY"])
    sem = Semaphore(semaphore)
    logger.info("并发度: %s", semaphore)

    new_rows: list[dict] = []
    parsed = [0]
    skipped = [0]
    lock = asyncio.Lock()

    async def process_one(aid, entry, session):
        sf = entry.get["source_file"]
        loop = asyncio.get_running_loop()
        read = lambda: Path(sf).read_text(encoding="utf-8", errors="replace")

        async with sem:
            try:
                html = await loop.run_in_executor(None, read)
                text, links = await loop.run_in_executor(
                    None,
                    lambda: _process_html(html, entry.get("url", "")),
                )
                items = await parse_announcement_fields(
                    text=text,
                    links=links,
                    exchange=entry["exchange"],
                    title=entry["title"],
                    publish_date=entry["pub_date"],
                    attachment_dir=Path(sf).parent,
                    session=session,
                )

                async with lock:
                    if not items:
                        skipped[0] += 1
                        logger.debug(
                            "  → 无 minoq/maxoq 信息，跳过 [%s] %s",
                            entry.get("exchange"), aid,
                        )
                        return
                    for item in items:
                        pub_date = entry.get("pub_date", "")
                        if not pub_date:
                            logger.warning(
                                "  ⚠ publish_date 为空，跳过 [%s] %s",
                                entry.get("exchange"), aid,
                            )
                            continue
                        new_rows.append({
                            "announcement_id": aid,
                            "publish_date": pub_date,
                            "exchange": entry["exchange"],
                            "product_code": item["product_code"],
                            "security_id": item["security_id"],
                            "field": item["field"],
                            "value": str(item["value"]),
                            "effective_date": item["effective_date"],
                            "announcement_title": entry["title"],
                            "evidence": item["evidence"],
                            "page_url": entry["url"],
                        })
                        parsed[0] += 1
                    logger.info(
                        "  + [%s] %s: %s 条",
                        entry["exchange"], aid, len(items),
                    )
            except Exception as e:
                logger.warning(
                    "解析失败 [%s] %s: %s", entry["exchange"], aid, e,
                )

    async def run_all(session):
        tasks = [process_one(aid, entry, session) for aid, entry in candidates]
        await asyncio.gather(*tasks)

    async def _main():
        conn = aiohttp.TCPConnector(limit=semaphore * 2, limit_per_host=semaphore)
        async with aiohttp.ClientSession(connector=conn) as session:
            await run_all(session)

    asyncio.run(_main())

    logger.info(
        "解析完成: +%s 条 (跳过 %s 条无信息)", parsed[0], skipped[0],
    )

    # 附件下载失败汇总
    failures = get_attachment_failures()
    if failures:
        logger.warning("=" * 50)
        logger.warning("附件下载失败汇总: %s 条", len(failures))
        for f in failures:
            logger.warning("  [%s] %s", f["exchange"], f["title"][:60])
            logger.warning("    URL: %s", f["url"])
            logger.warning("    Error: %s", f["error"])
        logger.warning("=" * 50)
    else:
        logger.info("附件下载: 全部成功")

    if dry_run:
        logger.info("DRY RUN — 不写入文件")
        return

    if not new_rows:
        logger.info("无新增字段，退出")
        return

    OUTPUT_FILE.parent.mkdir(parents=True, exist_ok=True)
    write_mode = "a" if OUTPUT_FILE.exists() else "w"
    with open(OUTPUT_FILE, mode=write_mode, newline="",
              encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=HEADER)
        if write_mode == "w":
            writer.writeheader()
        writer.writerows(new_rows)

    logger.info("写入完成: +%s 条 → %s", len(new_rows), OUTPUT_FILE)


if __name__ == "__main__":
    main()
